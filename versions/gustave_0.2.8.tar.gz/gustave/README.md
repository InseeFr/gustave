gustave
=======

Gustave: a User-oriented Statistical Toolkit for Analytical Variance
Estimation
