

#' Residuals calculation
#' @export

rescal <- function(y = NULL, x, w = NULL, by = NULL, precalc = NULL, colinearity.check = NULL){

  if(is.null(precalc)){

    if(is.null(w)) w <- rep(1, NROW(x))

    # Taking the by into account
    if(!is.null(by)) x <- Diagby(x, by)$y

    # Checking for colinearity
    if(isTRUE(colinearity.check) || (is.null(colinearity.check) && det(t(x) %*% x) == 0)){
      t <- as.vector(is.na(stats::lm(rep(1, NROW(x)) ~ . - 1, data = as.data.frame(as.matrix(x)))$coef))
      x <- x[, !t]
    }

    # Matrix inversion
    inv <- solve(t(x) %*% Diagonal(x = w) %*% x)

  }else list2env(precalc, envir = environment())

  if(is.null(y)){
    return(list(x = x, w = w, inv = inv))
  }else{
    e <- y - x %*% ( inv  %*% (t(x) %*% Diagonal(x = w) %*% y) )
    if(class(e) != class(y)) e <- methods::as(e, class(y))
    return(e)
  }

}

# n <- 70000; p <- 10; q <- 150; H <- 6; y <- matrix(rnorm(n*p),ncol=p); x <- Matrix(rnorm(n*q)*(runif(n*q) > 0.98),ncol=q); w <- runif(n); by <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)];
# precalc <- rescal(y = NULL, x = x, w = w, by = by)
# microbenchmark(times = 10, rescal(y, precalc = precalc), rescal(y, x = x, w = w, by = by))
# inv <- ginv(as.matrix(t(x * w) %*% x))
# t2 <- resCalib(y,x,w,inv)
# identical(t,t2)
# microbenchmark(rescal(y,x,w),rescal(y,x,w,inv),times = 10)

#' Variance approximation with Deville-Tillé formula
#'
#' @references Deville, Tille (2005), "Variance approximation under balanced sampling",
#' Journal of Statistical Planning and Inference 128, issue 2 569-591, formula 12 p. 10
#' @export

varDT <- function(y = NULL, pik, x = NULL, strata = NULL, fk = NULL, precalc = NULL, colinearity.check = NULL){

  # set.seed(1); n <- 2600; q <- 10; p <- 15; H <- 22; y <- matrix(rnorm(q*n),ncol=q); pik <- runif(n); x <- matrix(rnorm(p*n),ncol=p); x <- cbind(x, x[, 1]); strata <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; precalc <- NULL;
  # y = NULL; pik = bisect$piup; x = up_x; strata = bisect$reg; colinearity.check = TRUE

  if(is.null(precalc)){

    if(is.null(x)){
      x <- pik
      if(is.null(colinearity.check)) colinearity.check <- FALSE
    }
    p <- NCOL(x)

    # Stratification
    if(!is.null(strata)){
      t <- Diagby(x, strata)
      x <- t$y
      bycol <- t$bycol
      t <- table(strata)
      n <- as.vector(t[match(strata, names(t))])
    }else{
      bycol <- rep(1, p)
      n <- length(pik)
    }

    # Checking for colinearity
    if(isTRUE(colinearity.check) || (is.null(colinearity.check) && det(t(x) %*% x) == 0)){
      t <- as.vector(is.na(stats::lm(rep(1, NROW(x)) ~ . - 1, data = as.data.frame(as.matrix(x)))$coef))
      t2 <- sumby(!t, bycol)
      x <- x[, !t]
      p <- as.vector(t2[match(strata, names(t2))])
    }

    # A, ck and inv terms
    A <- t(x / pik)
    ck <- (1 - pik) * n / pmax(n - p, 1)
    inv <- solve(A %*% Diagonal(x = ck) %*% t(A))

  }else list2env(precalc, envir = environment())

  if(is.null(y)){
    # Diagonal term of the variance estimator
    # diago <- (ck - diag(Diagonal(x = ck) %*% (t(A) %*% inv %*% A) %*% Diagonal(x = ck)))/pik^2
    diago <- ck * (1 - diag(t(A) %*% inv %*% A) * ck)/pik^2
    names(diago) <- names(pik)
    return(list(
      precalc = list(pik = pik, A = A, ck = ck, inv = inv)
      , diago = diago
    ))
  }else{
    if(is.null(fk)) fk <- rep(1, length(pik))
    z <- y / pik
    zhat <- t(A) %*% inv %*% (A %*% Diagonal(x = ck) %*% z)
    return(colSums(ck * fk * (z - zhat)^2))
  }

}
# Tests
# set.seed(1); n <- 2332; q <- 1; p <- 14; H <- 22; y <- matrix(rnorm(q*n),ncol=q); pik <- runif(n); x <- matrix(rnorm(p*n),ncol=p); x <- cbind(x, x[, 1]); strata <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; inv <- NULL; fk <- NULL
# precalc <- varDT(pik = pik, x = x, strata = strata)$precalc
# t <- varDT(pik = pik, x = x, strata = strata)
# microbenchmark(times = 10, varDT(y, pik = pik, x = x, strata = strata), varDT(y, precalc = precalc))
# diago0 <- varDT(pik = pik, x = x, strata = strata)$diago
# abs(varDT(y,pik,x = pik) - varD(y,pik))
# abs(varDT(y,pik) - varDT(y,pik,strata = rep(1,NROW(y))))
# abs(varDT(y,pik,strata = strata) - varDst(y,pik,strata))
# abs(varDT(y,pik,x) - varDT2(y,pik,x))
# varDT(y, pik, x = x, strata = strata, fk = rnorm(n))

# max(abs(varDT(y = NULL,pik,strata = strata)[[1]] - varDst(y = NULL,pik,strata = strata)))

# set.seed(1); n <- 100; N <- 1000; pik <- rep(n/N,n); x <- pik; strata <- rep(1,n)
# varDT(y = NULL,pik,x = x, strata = strata)


# varDT(y,pik,x,strata = strata) / varDT(y,pik,strata = strata, x)

# library(microbenchmark)
# n <- 2600; q <- 1; p <- 15; H <- 22; y <- matrix(rnorm(q*n),ncol=q); pik <- runif(n); x <- matrix(c(pik,rnorm((p-1)*n)),ncol=p); strata <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; inv <- NULL; fk <- NULL
# microbenchmark(varDT(y,pik, x = x, strata = strata), times = 10)
# n <- 80000; q <- 100; p <- 1; H <- 2600; y <- matrix(rnorm(q*n),ncol=q); pik <- runif(n); x <- matrix(c(pik,rnorm((p-1)*n)),ncol=p); strata <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; inv <- NULL; fk <- NULL
# microbenchmark(varDT(y,pik, strata = strata), times = 10)
# n <- 20000; q <- 100; p <- 1; H <- 600; y <- matrix(rnorm(q*n),ncol=q); pik <- runif(n); x <- matrix(c(pik,rnorm((p-1)*n)),ncol=p); strata <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; inv <- NULL; fk <- NULL
# inv <- varDT(y = NULL,pik)$inv
# microbenchmark(varDT(y,pik,strata = strata,inv = inv),varDst(y,pik,strata = strata), times = 1)




#' TODO
#' @export
#' @references Wolter, 2008, p. 53

varCollapse <- function(y, group, strata = NULL){

  if(is.null(strata)) Ygh <- y else{
    Ygh <- sumby(y, by = strata)
    m <- match(row.names(Ygh), strata)
    group <- group[m]; strata <- strata[m]
  }

  n <- NROW(Ygh)
  t <- sumby(cbind(matrix(1,nrow = n),Ygh),by=group)
  m <- match(group,row.names(t))
  Lg <- t[m,1]
  Yg <- t[m,-1,drop = FALSE]

  r <- colSums((Lg/(Lg-1))*(Ygh-Yg/Lg)^2)

  return(r)

}


# Tests
# set.seed(1)
# n <- 20000
# p <- 10
# y <- matrix(rnorm(p*n),ncol=p)
# pik <- rep(1,n)
# strata <- sample(apply(expand.grid(letters,letters,letters),1,paste0,collapse = ""),n,replace = TRUE)
# # strata <- sample.int(26^2,n,replace = TRUE)
# w <- rbinom(n,500,0.5)
# valid <- !duplicated(strata)
# source("X:/HAB-Bases-UMS/MC/projets/#commun/R/collapse.R")
# group <- collapse(strata,w,valid)
#
# microbenchmark(
#   varC(y/w,group,strata = strata)
#   , varCollapse(y/w,group,strata = strata)
#   , times = 10
# )

#' TODO
#' @export
#' @references Wolter, 2007, pp. 298-353, v12

varsys <- function(y, pik){
  n <- nrow(as.matrix(y))
  return(
    ( (n - sum(pik)) / ( 2 * (n - 1)) ) *
      colSums(
        as.matrix(as.matrix(y)[-n,]/pik[-n] -
                    as.matrix(y)[-1,]/pik[-1])^2
        ,na.rm = T)
  )
}

varsysst <- function(y, pik, strata=rep(1,nrow(as.matrix(y)))){

  o <- order(strata);
  pik <- pik[o]; strata <- strata[o]
  p <- ncol(as.matrix(y))
  y <- matrix(matrix(y,ncol=p)[o,],ncol=p)

  id <- cumsum(!duplicated(strata))
  H <- max(id)
  f <- !duplicated(strata)
  l <- rev(!duplicated(rev(strata)))

  n <- c(which(f)[-1],length(strata) + 1) - which(f)
  sumpik <- (cumsum(pik) - c(0,cumsum(pik)[which(l)][-H])[id])[l]

  return(
    colSums(
      (n[id[-which(f)]] - sumpik[id[-which(f)]])/(2 * (n[id[-which(f)]] - 1)) *
        ( matrix(matrix(matrix(y,ncol=p)[-which(l),],ncol=p)/pik[-which(l)],ncol=p) -
            matrix(matrix(matrix(y,ncol=p)[-which(f),],ncol=p)/pik[-which(f)],ncol=p))^2
    )
  )
}


# y <- as.matrix(Y[,paste0("y",1:10),with = F]);strata <- Y$idzae;pik <- Y$piLog
# strata <- rep(1,nrow(Y))
#


#' TODO
#' @export

varB <- function(y, pik, fk = NULL){
  return(colSums((1 - pik) * (as.matrix(y)/pik)^2))
}

#' TODO
#' @export
#' @references doc de travail M2015 3 Gros Moussallam p. 19

varYG <- function(y = NULL,pikl){
  pik = diag(pikl)
  delta <- 1 - pik%*%t(pik)/pikl
  if(is.null(y)){
    diago <- - (1/pik^2)*rowSums(delta - diag(x = diag(delta)))
    names(diago) <- row.names(pikl)
    return(diago)
  }else{
    var <- colSums((y/pik) * (delta %*% (y/pik)) - delta %*% (y/pik)^2)
    return(var)
  }
}

# Banc de tests
# N <- 100
# n <- 10
# y <- rnorm(n)
# pik <- rep(n/N,n)
# pikl <- matrix(rep((n*(n-1))/(N*(N-1))),ncol=n,nrow=10)
# diag(pikl) <- pik
# varYG(y, pikl = pikl)
# varDT(y, pik = pik)
#
# y <- c(4,2)
# pikl <- matrix(c(0.1111,0.1111,0,0,0.1111,1,0.3333,0.5556,0,0.3333,0.3333,0,0,0.5556,0,0.5556),ncol=4)[1:2,1:2]
# pik <- diag(pikl)
# varYG(y, pikl = pikl)
# varD(y, pik = pik)


#' TODO
#' @export
#' @references doc de travail M2015 3 Gros Moussallam p.11. et p. 19 pour la version matricielle

varGR <- function(y, alphakl, pikl = matrix(1, ncol = NCOL(alphakl), nrow = NROW(alphakl)), g = rep(0, NROW(alphakl))){
  alphak <- diag(alphakl)
  delta <- (alphakl - alphak %*% t(alphak)) / (alphakl * pikl)
  return(colSums((y/alphak) * (delta %*% (y/alphak)) ) - colSums(delta)%*%((y/alphak)^2) + sum((g/diag(pikl))*(y/alphak)))
}
