library(testthat)
library(gustave)

test_check("gustave")
