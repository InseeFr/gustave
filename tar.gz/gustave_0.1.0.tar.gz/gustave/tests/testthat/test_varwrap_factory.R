

context("varwrap_factory - Function and data defined in globalenv()")

source("data.R")

varfun_test <- function(y, eurostat = FALSE) list(var = abs(colSums(y)))

test_that("varwrap_test can be defined", {
  expect_error(
    varwrap_test <<- varwrap_factory(
      varfun = varfun_test, id_default = id3
      , idref = ref$idref, wref = ref$wref
    )
    , regexp = NA)
})

# ls(environment(varwrap_test))
# varwrap_test(data = survey, total(quali))



context("varwrap_factory - Function and data defined in another function")

prepare_test <- function(){

  source("data.R")
  a <- 1

  varfun_test <- function(y, eurostat = FALSE) list(var = abs(colSums(y)))

  varwrap_test <<- varwrap_factory(
    varfun = varfun_test, id_default = id3
    , idref = ref$idref, wref = ref$wref
    , objects_to_include = "a"
  )
}

test_that("varwrap_test can be defined", {
  expect_error(
    varwrap_test <<- prepare_test()
    , regexp = NA)
})
