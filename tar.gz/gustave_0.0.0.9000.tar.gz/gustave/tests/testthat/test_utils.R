
# source("data.R")

library(testthat)

context("Sanitize")

varwrap_factory_test <- function(objects_to_include){
  varwrap <- function(){}
  varwrap <- sanitize(varwrap, objects = objects_to_include)
  return(varwrap)
}

a <- 1
fun <- function(){}
clos <- function(){
  b <- 2
  function(){}
}

preparer_test <- function(){
  b <- 1
  varwrap_factory_test(objects = "b")
}

test_that("varwrap_test1 can be defined", {
  expect_error(
    varwrap_test1 <<- varwrap_factory_test(objects = c("a", "fun", "clos"))
  , regexp = NA)
})


test_that("varwrap_test1 has globalenv() as parent.env()", {
  expect_equal(parent.env(environment(varwrap_test1)), globalenv())
})

test_that("varwrap_test1 contains what it should", {
  expect_equal(setdiff(ls(environment(varwrap_test1)), c("a", "fun", "clos")), as.character(c()))
})


#
#
# test_that("varwrap_test2 can be defined", {
#   expect_error(varwrap_test2 <- preparer_test(), NA)
# })



