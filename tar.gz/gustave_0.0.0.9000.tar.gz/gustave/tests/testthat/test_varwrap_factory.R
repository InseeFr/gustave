
source("data.R")

varfun_dummy <- function(y, eurostat = FALSE) list(var = abs(colSums(y)))
varwrap_dummy <- varwrap_factory(
  varfun = varfun_dummy, id_default = id3
  , idref = ref$idref3, wref = ref$wref3
)

test_that("varwrap_factory is a function", {
  expect_is(varwrap_dummy, "function")
})
