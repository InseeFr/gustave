#' TODO

Diagby <- function(y = NULL, by, p = 1){
  # y <- as(Matrix(TRUE, ncol = 10, nrow = length(rowby)), "TsparseMatrix"); by <- rowby; p <- 2
  # y <- x; by <- strata
  byrow <- by
  by <- as.factor(by)
  H <- length(levels(by))
  if(is.null(y)){
    t <- lapply(1:H, function(i) which(as.integer(by) == i))
    y <- sparseMatrix(
      i = do.call(base::c, lapply(t, rep, p))
      , j = do.call(base::c, lapply(1:(p * H), function(k) rep(k, length(t[[ceiling(k/p)]]))))
      , x = TRUE, giveCsparse = FALSE, check = FALSE
    )
    y@Dim[1] <- length(by)
  }else{
    p <- NCOL(y)
    if(!methods::is(y,"TsparseMatrix")) y <- methods::as(if(p == 1) as.matrix(y) else y, "TsparseMatrix")
    y@j <- as.integer(((as.numeric(by) - 1) * p)[y@i + 1] + y@j)
    y@Dim <- c(y@Dim[1], as.integer(y@Dim[2] * H))
    if(any(is.na(by))){na <- is.na(y@j); y@x <- y@x[!na]; y@i <- y@i[!na]; y@j <- y@j[!na]}
  }
  bycol <- rep(levels(by), each = p)
  bycol <- if(is.factor(byrow)) as.factor(bycol) else methods::as(bycol, class(byrow))
  return(list(y = y, byrow = byrow, bycol = bycol))
}
# rowby <- as.factor(c(rep(1, 5), NA, rep(2, 8), rep(NA, 4)))
# colby <- c(rep(1, 2), rep(2, 2))
# all.equal(Diagby(by = rowby, p = 10), Diagby(y = Matrix(TRUE, ncol = 10, nrow = length(rowby)), by = rowby))


#' Efficient sum by group using Matrix
#' @export

sumby <- function(y, by = NULL, w = NULL, dense = FALSE){

  n <- NROW(y)
  if(!is.null(w)) y <- y * w
  nullBy <- is.null(by)
  if(nullBy) by <- rep(1,n)
  if(anyNA(by)){
    byNA <- is.na(by)
    y <- y[!byNA, , drop = FALSE]
    by <- by[!byNA]
    n <- NROW(y)
  }

  by <- as.factor(by)
  x <- Diagby(rep(TRUE, n), by)$y
  r <- t(x) %*% y

  if(!grepl(pattern = "matrix", x = class(y), ignore.case = TRUE)){
    r <- as.vector(r)
    if(!nullBy) names(r) <- levels(by)
  }else{
    if(is.matrix(y) || dense) r <- as.matrix(r)
    if(!nullBy) rownames(r) <- levels(by)
  }

  return(r)

}

# set.seed(1); n <- 20000; p <- 10; H <- 600; y <- as(Matrix(rnorm(p*n),ncol=p),"TsparseMatrix"); by <- rep(1:H,n %/% H + 1)[1:n][sample.int(n)]; by <- as.factor(by); w <- rnorm(n)
# library(microbenchmark)
# microbenchmark(r <- sumby(y,by), times = 10)
#
#   n <- 4500000; y <- as.matrix(rnorm(n)); by <- sample(1:20000,n,replace = TRUE)
#   library(microbenchmark)
#   microbenchmark(
#     sumby(y,by)
#     , data.table(as.matrix(y))[,j=list(blabla=sum(V1)),by=by]
#     , aggregate(as.matrix(y),list(by),sum)
#     , times = 10L
#   )


#' Expand a matrix with zeros based on rownames matching
#' @export

add0 <- function(y, rownames){
  compl <- setdiff(rownames, rownames(y))
  compl <- matrix(
    0, nrow = length(compl), ncol = NCOL(y), dimnames = list(compl)
  )
  rbind(y, compl)[rownames, , drop = FALSE]
}


#' Isolate a function and embed objects in its definition environment

sanitize <- function(fun, objects, from = parent.frame(), parent = globalenv(), not_closure = list(globalenv())){
  e <- new.env(parent = parent)
  (assign_rec <- function(objects, from, to, not_closure){
    for(n in objects){
      where_n <- if(is.null(from)) pryr::where(n) else pryr::where(n, from)
      not_closure <- c(not_closure, where_n)
      env_n <- environment(get_n <- get(n, where_n))
      if(!is.function(get_n)){ # All objects excluding functions
        assign(n, get_n, envir = to)
      }else if(any(sapply(not_closure, identical, env_n))){ # All functions excluding closures
        assign(n, eval(parse(text = deparse(get_n)), envir = to), envir = to)
      }else{ # Closures
        tmp <- new.env(parent = to)
        assign_rec(ls(env_n, all.names = TRUE), from = env_n, to = tmp, not_closure = not_closure)
        assign(n, eval(parse(text = deparse(get_n)), envir = tmp), envir = to)
      }
    }
  })(objects = objects, from = from, to = e, not_closure = not_closure)
  eval(parse(text = deparse(fun)), envir = e)
}
